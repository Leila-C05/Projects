﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZgloszeniaAwari.Entities
{
    internal class Zgloszenie
    {
        public int Id { get; set; }
        public Osoba TworcaZgloszenia { get; set; }
        public int TworcaZgloszeniaId { get; set; }
        public Osoba PrzypisaneDo { get; set; }
        public int PrzypisaneDoId { get; set; }
        public Kategoria Kategoria { get; set; }
        public int KategoriaId { get; set; }
        public DateTime DataDodania { get; set; }
        public bool Wykonane { get; set; } = false;

        // Nowe właściwości dodane
        public string ImieUzytkownika { get; set; }
        public string NazwiskoUzytkownika { get; set; }
        public string OpisAwarii { get; set; }
        public string NazwaKategori { get; set; }
        public string ImiePrzypisane { get; set; }
        public string NazwiskoPrzypisane { get; set; }

        public Osoba OsobaZglaszajaca { get; set; } // opcja na 6
    }
}