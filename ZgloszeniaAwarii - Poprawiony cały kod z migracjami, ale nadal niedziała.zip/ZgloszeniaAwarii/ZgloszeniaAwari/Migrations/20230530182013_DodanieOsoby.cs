﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ZgloszeniaAwari.Migrations
{
    /// <inheritdoc />
    public partial class DodanieOsoby : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Zgloszenia_Osoby_PrzypisaneDoId",
                table: "Zgloszenia");

            migrationBuilder.DropForeignKey(
                name: "FK_Zgloszenia_Osoby_TworcaZgloszeniaId",
                table: "Zgloszenia");

            migrationBuilder.AddForeignKey(
                name: "FK_Zgloszenia_Osoby_PrzypisaneDoId",
                table: "Zgloszenia",
                column: "PrzypisaneDoId",
                principalTable: "Osoby",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Zgloszenia_Osoby_TworcaZgloszeniaId",
                table: "Zgloszenia",
                column: "TworcaZgloszeniaId",
                principalTable: "Osoby",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Zgloszenia_Osoby_PrzypisaneDoId",
                table: "Zgloszenia");

            migrationBuilder.DropForeignKey(
                name: "FK_Zgloszenia_Osoby_TworcaZgloszeniaId",
                table: "Zgloszenia");

            migrationBuilder.AddForeignKey(
                name: "FK_Zgloszenia_Osoby_PrzypisaneDoId",
                table: "Zgloszenia",
                column: "PrzypisaneDoId",
                principalTable: "Osoby",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Zgloszenia_Osoby_TworcaZgloszeniaId",
                table: "Zgloszenia",
                column: "TworcaZgloszeniaId",
                principalTable: "Osoby",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
