﻿using System;
using System.Windows;
using ZgloszeniaAwari.Entities;

namespace ZgloszeniaAwarii
{
    public partial class AddZgloszenieWindow : Window
    {
        public AddZgloszenieWindow()
        {
            InitializeComponent();
        }

        private void btnDodajZgloszenie_Click(object sender, RoutedEventArgs e)
        {
            string ImieUzytkownika = tbImieUzytkownika.Text;
            string NazwiskoUzytkownika = tbNazwiskoUzytkownika.Text;
            string OpisAwarii = tbOpisAwarii.Text;
            string NazwaKategori = tbNazwaKategori.Text;
            string ImiePrzypisane = tbImiePrzypisane.Text;
            string NazwiskoPrzypisane = tbNazwiskoPrzypisane.Text;

            // Walidacja wprowadzanych danych.
            if (string.IsNullOrWhiteSpace(ImieUzytkownika) || string.IsNullOrWhiteSpace(NazwiskoUzytkownika) ||
               string.IsNullOrWhiteSpace(OpisAwarii) || string.IsNullOrWhiteSpace(NazwaKategori) ||
               string.IsNullOrWhiteSpace(ImiePrzypisane) || string.IsNullOrWhiteSpace(NazwiskoPrzypisane))
            {
                MessageBox.Show("Wszystkie pola muszą być wypełnione.");
                return;
            }
          

            // Sprawdzenie wielkości liter imion i nazwisk.
            if (!char.IsUpper(ImieUzytkownika[0]) || !char.IsUpper(NazwiskoUzytkownika[0]) ||
               !char.IsUpper(ImiePrzypisane[0]) || !char.IsUpper(NazwiskoPrzypisane[0]))
            {
                MessageBox.Show("Imiona i nazwiska powinny zaczynać się od wielkiej litery.");
                return;
            }

            Zgloszenie noweZgloszenie = new Zgloszenie
            {
                ImieUzytkownika = ImieUzytkownika,
                NazwiskoUzytkownika = NazwiskoUzytkownika,
                OpisAwarii = OpisAwarii,
                NazwaKategori = NazwaKategori,
                ImiePrzypisane = ImiePrzypisane,
                NazwiskoPrzypisane = NazwiskoPrzypisane
            };
            using (var context = new ZgloszeniaAwariiDbContext())
            {
                context.Zgloszenia.Add(noweZgloszenie);
                context.SaveChanges();
            }

            MessageBox.Show("Zgłoszenie zostało dodane.");

            // Opcjonalnie, wyczyść pola formularza po dodaniu zgłoszenia
            tbImieUzytkownika.Text = "";
            tbNazwiskoUzytkownika.Text = "";
            tbOpisAwarii.Text = "";
            tbNazwaKategori.Text = "";
            tbImiePrzypisane.Text = "";
            tbNazwiskoPrzypisane.Text = "";
        }
    }
}
        
        



